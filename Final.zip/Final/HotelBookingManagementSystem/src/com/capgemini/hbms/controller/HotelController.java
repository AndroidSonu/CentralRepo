package com.capgemini.hbms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	IHotelService hotelService;

	public IHotelService getHotelService() {
		return hotelService;
	}

	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}

	@RequestMapping("/index")
	public String showIndex() {
		return ("index");
	}

	@RequestMapping("/register")
	public String showHome() {
		return ("homepage");
	}

	@RequestMapping(value = "/custRegister", method = RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("users") Users user) {
		ModelAndView mv = new ModelAndView();
		System.out.println(user.toString());
		int a = hotelService.addUser(user);
		if (a > 0) {
			String msg = "Registered with User ID:" + a;
			mv.setViewName("custSuccess");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("custError");
			mv.addObject("msg", "Registration Failed!!!");
		}
		return mv;
	}

	@RequestMapping("/adminPage")
	public String showAdmin() {
		return ("adminLogin");
	}

	@RequestMapping(value = "/verifyAdmin", method = RequestMethod.POST)
	public ModelAndView verifyAdminLogin(@RequestParam("userId") int id,
			@RequestParam("password") String pwd, HttpServletRequest request) {
		ModelAndView mv = null;
		boolean status = hotelService.verifyLogin(id, pwd);
		Users user = hotelService.getUser(id);
		HttpSession session = request.getSession(false);
		if (status) {
			session.setAttribute("user", user);
			mv = new ModelAndView("adminFunctions");
		} else {
			mv = new ModelAndView("logout", "msg", "Unauthorised Access!!!");
		}
		return mv;
	}

	@RequestMapping("/custPage")
	public String showCust() {
		return ("custLogin");
	}

	@RequestMapping(value = "/verifyCust", method = RequestMethod.POST)
	public ModelAndView verifyCustLogin(@RequestParam("userId") int id,
			@RequestParam("password") String pwd, HttpServletRequest request) {
		ModelAndView mv = null;
		boolean status = hotelService.verifyCustLogin(id, pwd);
		Users user = hotelService.getUser(id);
		HttpSession session = request.getSession(false);
		if (status) {
			session.setAttribute("user", user);
			mv = new ModelAndView("custFunctions");
		} else {
			mv = new ModelAndView("logout", "msg", "Unauthorised Access!!!");
		}
		return mv;
	}

	@RequestMapping("/search")
	ModelAndView getCity() {
		ModelAndView mv = null;
		List<Hotel> hotelList = hotelService.getHotelList();
		Set<String> distinctCity = new TreeSet<String>();
		for (Hotel city : hotelList) {
			distinctCity.add(city.getCity());
		}
		mv = new ModelAndView("search", "distinctCity", distinctCity);
		mv.addObject("isFirst", true);

		return mv;

	}

	@RequestMapping("/listByCity")
	public ModelAndView listByCity(@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView mv = null;
		List<Hotel> hotelListByCity = hotelService.getHotelListByCity(hotel
				.getCity());
		if (!hotelListByCity.isEmpty()) {
			mv = new ModelAndView("search", "hotelList", hotelListByCity);
		} else {
			mv = new ModelAndView("custError", "msg", "Hotels Not Available");
		}
		return mv;
	}

	@RequestMapping("/roomDetails")
	public ModelAndView roomList(@RequestParam("hotelId") int id) {
		ModelAndView mv = null;
		System.out.println("Hello");
		List<RoomDetails> roomList = hotelService.getRoomListByHotelIdAndType(id);
		System.out.println(roomList.toString());
		if (!roomList.isEmpty()) {
			mv = new ModelAndView("search", "roomList", roomList);
			mv.addObject("isFirst", false);
		} else {
			mv = new ModelAndView("custError", "msg", "Rooms Not Available");
		}
		return mv;
	}

	@RequestMapping("/book")
	public ModelAndView book(@RequestParam("roomId") int roomId,
			@RequestParam("perNightRate") double perNightRate,
			HttpServletRequest request) {
		ModelAndView mv = null;
		HttpSession session = request.getSession(false);
		session.setAttribute("roomid", roomId);
		session.setAttribute("rate", perNightRate);
		Users user = (Users) session.getAttribute("user");
		mv = new ModelAndView("bookPage", "userId", user.getUserId());
		return mv;
	}

	@RequestMapping("/confirmBook")
	public ModelAndView confirmBook(
			@RequestParam("bookedFrom") String bookedFrom,
			@RequestParam("bookedTo") String bookedTo,
			@RequestParam("noOfAdults") int noa,
			@RequestParam("noOfChildren") int noc, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession(false);
		double rate = (double) session.getAttribute("rate");
		Users user = (Users) session.getAttribute("user");
		int roomId = (int) session.getAttribute("roomid");
		int userId = user.getUserId();
		BookingDetails bookingDetail = hotelService.addBookingDetails(rate,
				bookedFrom, bookedTo, noa, noc, roomId, userId);
		int a = bookingDetail.getBookingId();
		hotelService.updateRoomAvailability(bookingDetail.getRoomId());

		if (a > 0) {
			String msg = "Booked with Booking ID:" + a + "<br> Amount Paid:"
					+ bookingDetail.getAmount();
			mv.setViewName("custSuccess");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("custError");
			mv.addObject("msg", "Booking Failed!!!");
		}
		return mv;
	}

	@RequestMapping("/check")
	public ModelAndView showCheck() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("checkPage");
		mv.addObject("isFirst", true);
		return mv;
	}

	@RequestMapping("/checkStatus")
	public ModelAndView book(@RequestParam("bookingId") int bookingId) {
		ModelAndView mv = new ModelAndView();
		List<BookingDetails> list = hotelService
				.getBookingDetailsByBookingId(bookingId);
		if (!list.isEmpty()) {
			mv.setViewName("checkPage");
			mv.addObject("list", list);
		} else {
			mv.setViewName("custError");
			mv.addObject("msg", "No Booking is Done");
		}
		return mv;
	}

	@RequestMapping("/logout")
	public ModelAndView LogOut(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
			mv.addObject("msg", "You have successfully logged out.");
		}
		mv.setViewName("logout");
		return mv;
	}

	// ---------------------------------Manage Hotel-------------------------

	@RequestMapping("/home")
	public String showadminHome() {
		return ("adminFunctions");
	}

	@RequestMapping("/custHome")
	public String showCustHome() {
		return ("custFunctions");
	}

	@RequestMapping("/hotel")
	public String showHotels() {
		return ("hotels");
	}

	@RequestMapping("/addHotel")
	public String showAddHotelPage() {
		return ("addHotelPage");
	}

	@RequestMapping("/addHotels")
	public ModelAndView addHotels(@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView mv = new ModelAndView();
		int id = hotelService.addHotel(hotel);
		if (id > 0) {
			mv.setViewName("adminSuccess");
			mv.addObject("msg", "Hotel is Added With Hotel ID :" + id);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "Hotel is Not Added");
		}
		return mv;
	}

	@RequestMapping("/deleteHotel")
	public ModelAndView showDeleteHotelPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("deleteHotel");
		mv.addObject("isFirst", true);
		return mv;
	}

	@RequestMapping("/deleteHotels")
	public ModelAndView deleteHotels(@RequestParam("hotelId") int hotelId) {
		ModelAndView mv = new ModelAndView();
		Hotel hotel = hotelService.getHotel(hotelId);
		if (hotel != null) {
			boolean status = hotelService.deleteHotel(hotelId);
			List<Hotel> list = hotelService.getHotelList();
			if (status) {
				mv.setViewName("deleteHotel");
				mv.addObject("list", list);
			} else {
				mv.setViewName("adminError");
				mv.addObject("msg", "No Hotel is Found To Delete");
			}
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Hotel is Found");
		}
		return mv;
	}

	@RequestMapping("/modifyHotel")
	public ModelAndView showModifyHotelPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("modifyHotel");
		mv.addObject("isFirst", true);
		return mv;
	}

	@RequestMapping("/modifyHotels")
	public ModelAndView modifyHotels(@RequestParam("hotelId") int hotelId,
			@RequestParam("description") String description,
			@RequestParam("avgRatePerNight") double rate) {
		ModelAndView mv = new ModelAndView();
		Hotel hotel = hotelService.modifyHotel(description, rate, hotelId);
		if (hotel != null) {
			mv.setViewName("modifyHotel");
			mv.addObject("hotel", hotel);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Hotel is Found To Update");
		}
		return mv;
	}

	// ---------------------------------Manage Rooms-------------------------

	@RequestMapping("/room")
	public String showRoomss() {
		return ("rooms");
	}

	@RequestMapping("/addRoom")
	public String showAddRoomsPage() {
		return ("addRoomPage");
	}

	@RequestMapping("/addRooms")
	public ModelAndView addRooms(@ModelAttribute("room") RoomDetails room) {
		ModelAndView mv = new ModelAndView();
		int id = hotelService.addRoom(room);
		if (id > 0) {
			mv.setViewName("adminSuccess");
			mv.addObject("msg", "Room is Added With Room ID :" + id);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "Room is Not Added");
		}
		return mv;
	}

	@RequestMapping("/deleteRoom")
	public ModelAndView showDeleteRoomPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("deleteRoom");
		mv.addObject("isFirst", true);
		return mv;
	}

	@RequestMapping("/deleteRooms")
	public ModelAndView deleteRooms(@RequestParam("roomId") int roomId) {
		ModelAndView mv = new ModelAndView();
		RoomDetails room = hotelService.getRoom(roomId);

		if (room != null) {
			boolean status = hotelService.deleteRoom(roomId);
			List<RoomDetails> list = hotelService.getRoomList();
			if (status) {
				mv.setViewName("deleteRoom");
				mv.addObject("list", list);
			} else {
				mv.setViewName("adminError");
				mv.addObject("msg", "No Room is Found To Delete");
			}
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Room is Found");
		}
		return mv;
	}

	@RequestMapping("/modifyRoom")
	public ModelAndView showModifyRoomPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("modifyRoom");
		mv.addObject("isFirst", true);
		return mv;
	}

	@RequestMapping("/modifyRooms")
	public ModelAndView modifyRooms(@RequestParam("roomId") int roomId,
			@RequestParam("perNightRate") double rate) {
		ModelAndView mv = new ModelAndView();
		RoomDetails room = hotelService.modifyRoom(roomId, rate);
		if (room != null) {
			mv.setViewName("modifyRoom");
			mv.addObject("room", room);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Room is Found To Update");
		}
		return mv;
	}

	// ---------------------------------Generate
	// Reports-------------------------

	@RequestMapping("/report")
	public String showReports() {
		return ("reports");
	}

	@RequestMapping("/hotelList")
	public ModelAndView hotelList() {
		ModelAndView mv = new ModelAndView();
		List<Hotel> list = hotelService.getHotelList();
		if (!list.isEmpty()) {
			mv.setViewName("hotelList");
			mv.addObject("list", list);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Hotels Are Available");
		}
		return mv;
	}

	@RequestMapping("/bookingListByHotelId")
	public ModelAndView bookingListByHotelId() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("custSuccess");
		mv.addObject("msg", "Service is Temporarily Not Available");
		return mv;
	}

	@RequestMapping("/listByHotelId")
	public ModelAndView listByHotelId(@RequestParam("hotelId") int hotelId) {
		ModelAndView mv = new ModelAndView();
		List<BookingDetails> bookList = new ArrayList<BookingDetails>();
		List<RoomDetails> list = hotelService.getRoomListByHotelId(hotelId);
		for (RoomDetails room : list) {
			bookList.add(hotelService.getBookingDetails(room.getRoomId()));
		}
		if (!bookList.isEmpty()) {
			mv.setViewName("bookList");
			mv.addObject("list", bookList);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Bookings Are Available in this Hotel");
		}
		return mv;
	}

	@RequestMapping("/guestList")
	public ModelAndView guestList() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("custSuccess");
		mv.addObject("msg", "Service is Temporarily Not Available");
		return mv;
	}

	@RequestMapping("/guestListByHotelId")
	public ModelAndView guestListByHotelId(@RequestParam("hotelId") int hotelId) {
		ModelAndView mv = new ModelAndView();
		List<Users> list = hotelService.getGuestListByHotel_Id(hotelId);
		if (!list.isEmpty()) {
			mv.setViewName("guestList");
			mv.addObject("list", list);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Guests Are Available in this Hotel");
		}
		return mv;
	}

	@RequestMapping("/bookingListByDate")
	public ModelAndView bookingListByDate() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("custSuccess");
		mv.addObject("msg", "Service is Temporarily Not Available");
		return mv;
	}

	@RequestMapping("/ListByDate")
	public ModelAndView ListByDate(@RequestParam("date") Date date) {
		ModelAndView mv = new ModelAndView();
		List<BookingDetails> list = hotelService.getBookingDetailsByDate(date);
		if (!list.isEmpty()) {
			mv.setViewName("bookingList");
			mv.addObject("list", list);
		} else {
			mv.setViewName("adminError");
			mv.addObject("msg", "No Bookings Are Available in this Date");
		}
		return mv;
	}
}