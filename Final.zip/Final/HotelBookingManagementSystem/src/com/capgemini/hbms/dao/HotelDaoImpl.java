package com.capgemini.hbms.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao {

	@PersistenceContext
	private EntityManager entityManager;

	static Logger myLogger = Logger.getLogger("myLogger");

	@Override
	public boolean verifyLogin(int id, String password) {

		Users user = entityManager.find(Users.class, id);
		if (user != null) {	
			if (user.getUserId() == id && user.getPassword().equals(password)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	@Override
	public boolean verifyCustLogin(int id, String password) {
		Users user = entityManager.find(Users.class, id);
		if (user != null) {
			if (user.getUserId() == id && user.getPassword().equals(password)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	@Override
	public int addHotel(Hotel hotel) {
		entityManager.persist(hotel);
		entityManager.flush();
		myLogger.info(hotel.toString());
		return hotel.getHotelId();

	}

	@Override
	public boolean deleteHotel(int hotelId) {
		entityManager.remove(entityManager.find(Hotel.class, hotelId));
		if (entityManager.find(Hotel.class, hotelId) == null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Hotel modifyHotel(String hotelDesc, double avgRate, int hotelId) {
		Hotel hotel = entityManager.find(Hotel.class, hotelId);
		hotel.setDescription(hotelDesc);
		hotel.setAvgRatePerNight(avgRate);
		return entityManager.merge(hotel);
	}

	@Override
	public int addRoom(RoomDetails room) {
		entityManager.persist(room);
		entityManager.flush();
		myLogger.info(room.toString());
		return room.getRoomId();
	}

	@Override
	public boolean deleteRoom(int roomId) {
		entityManager.remove(entityManager.find(RoomDetails.class, roomId));
		if (entityManager.find(Hotel.class, roomId) == null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public RoomDetails modifyRoom(int roomId, double rent) {
		RoomDetails room = entityManager.find(RoomDetails.class, roomId);
		room.setPerNightRate(rent);
		;
		return entityManager.merge(room);
	}

	@Override
	public List<Hotel> getHotelList() {
		TypedQuery<Hotel> query = entityManager.createQuery("from Hotel",
				Hotel.class);
		myLogger.info(query.getResultList().toString());
		return query.getResultList();
	}

	@Override
	public BookingDetails getBookingDetails(int roomId) {
		TypedQuery<BookingDetails> bookingdetail = entityManager.createQuery(
				"SELECT bd FROM BookingDetails bd WHERE roomId=:id",
				BookingDetails.class);
		bookingdetail.setParameter("id", roomId);
		myLogger.info(bookingdetail.getSingleResult().toString());
		return bookingdetail.getSingleResult();
	}

	@Override
	public List<RoomDetails> getRoomListByHotelId(int hotelId) {
		TypedQuery<RoomDetails> roomDetails = entityManager.createQuery(
				"SELECT rd FROM RoomDetails rd WHERE hotelId=:id",
				RoomDetails.class);
		roomDetails.setParameter("id", hotelId);
		myLogger.info(roomDetails.getResultList().toString());
		return roomDetails.getResultList();
	}

	@Override
	public List<BookingDetails> getBookingDetailsByDate(Date bookingDate) {
		TypedQuery<BookingDetails> bookingdetail = entityManager
				.createQuery(
						"select booking from BookingDetails booking where booking.bookedFrom=:date",
						BookingDetails.class);
		bookingdetail.setParameter("date", bookingDate);
		myLogger.info(bookingdetail.getResultList().toString());
		return bookingdetail.getResultList();
	}

	@Override
	public List<Users> getGuestListByHotel_Id(int hotel_id) {
		TypedQuery<Users> guestDetail = entityManager
				.createQuery(
						"SELECT DISTINCT ud.userId,ud.userName FROM Users ud JOIN BookingDetails bd ON bd.userId=ud.userId JOIN RoomDetails rd ON rd.roomId=bd.roomId WHERE rd.hotelId=:id",
						Users.class);
		guestDetail.setParameter("id", hotel_id);
		myLogger.info(guestDetail.getResultList().toString());
		return guestDetail.getResultList();
	}

	@Override
	public BookingDetails addBookingDetails(double rate, String date1,
			String date2, int noOfAdults, int noOfChildren, int roomId,
			int userId) {
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		BookingDetails bd = new BookingDetails();

		try {
			Date from = sdf.parse(date1);
			Date to = sdf.parse(date2);
			long difference = to.getTime() - from.getTime();
			float daysBetween = (difference / (1000 * 60 * 60 * 24));
			double amount = rate * daysBetween * (noOfAdults + noOfChildren);

			bd.setAmount(amount);
			bd.setBookedFrom(from);
			bd.setBookedTo(to);
			bd.setNoOfAdults(noOfAdults);
			bd.setNoOfChildren(noOfChildren);
			bd.setRoomId(roomId);
			bd.setUserId(userId);
			entityManager.persist(bd);
			entityManager.flush();

		} catch (ParseException e) {
			myLogger.info(e.getMessage());
		}
		return bd;

	}

	@Override
	public List<Hotel> getHotelListByCity(String city) {
		TypedQuery<Hotel> bookingdetail = entityManager.createQuery(
				"select h from Hotel h where h.city=:city", Hotel.class);
		bookingdetail.setParameter("city", city);
		return bookingdetail.getResultList();
	}

	@Override
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId) {
		TypedQuery<RoomDetails> roomDetails = entityManager
				.createQuery(
						"SELECT rd FROM RoomDetails rd WHERE hotelId=:id AND availability=1",
						RoomDetails.class);
		roomDetails.setParameter("id", hotelId);
		return roomDetails.getResultList();
	}

	@Override
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId) {
		TypedQuery<BookingDetails> bookingdetail = entityManager
				.createQuery(
						"select booking from BookingDetails booking where booking.bookingId=:id",
						BookingDetails.class);
		bookingdetail.setParameter("id", bookingId);
		return bookingdetail.getResultList();
	}

	@Override
	public int addUser(Users user) {
		entityManager.persist(user);
		entityManager.flush();
		return user.getUserId();

	}

	@Override
	public RoomDetails updateRoomAvailability(int room_id) {
		RoomDetails room = entityManager.find(RoomDetails.class, room_id);
		room.setAvailability(0);
		return entityManager.merge(room);
	}

	@Override
	public Users getUser(int userId) {
		return entityManager.find(Users.class, userId);
	}

	@Override
	public List<RoomDetails> getRoomList() {
		TypedQuery<RoomDetails> roomDetail = entityManager.createQuery(
				"select rd from RoomDetails rd", RoomDetails.class);
		return roomDetail.getResultList();
	}

	@Override
	public Hotel getHotel(int hotelId) {
		return entityManager.find(Hotel.class, hotelId);
	}

	@Override
	public RoomDetails getRoom(int roomId) {
		return entityManager.find(RoomDetails.class, roomId);
	}

}
