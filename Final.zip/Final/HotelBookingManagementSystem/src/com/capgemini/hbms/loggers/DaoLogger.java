package com.capgemini.hbms.loggers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.log4j.HTMLLayout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.SimpleLayout;
import org.apache.log4j.WriterAppender;

public class DaoLogger {

	public static Logger myLogger = Logger.getLogger(DaoLogger.class);

	static WriterAppender appender = null;
	static PatternLayout hlay=new PatternLayout();
	static {
		try {
			FileOutputStream fout = new FileOutputStream("logger.html");
			appender = new WriterAppender(hlay, fout);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		myLogger.addAppender(appender);

	}

}
