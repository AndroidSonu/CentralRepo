package com.cg.ca.dto;

/**
 * @author arhansda
 *
 */
public enum Category {
	FAMILY,FRIENDS,ACQUAINTANCE,WORK,OTHERS;
}
