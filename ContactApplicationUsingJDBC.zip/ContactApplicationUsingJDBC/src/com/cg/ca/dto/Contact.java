package com.cg.ca.dto;

/**
 * @author arhansda
 *
 */
public class Contact {
	
	private int contId ;
	private String firstName;
	private String midName;
	private String lastName;
	private Gender gender;
	private String mobileNumber1;
	private String mobileNumber2;
	private String officialEmail;
	private String homeEmail;
	private Category category;
	private String Organisation;
	private String Designation;
	
	public Contact() {
		//default constructor
	}
	public Contact(int contId, String firstName, String midName,
			String lastName, Gender gender, String mobileNumber1,
			String mobileNumber2, String officialEmail, String homeEmail,
			Category category, String organisation, String designation) {
		this.contId = contId;
		this.firstName = firstName;
		this.midName = midName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNumber1 = mobileNumber1;
		this.mobileNumber2 = mobileNumber2;
		this.officialEmail = officialEmail;
		this.homeEmail = homeEmail;
		this.category = category;
		this.Organisation = organisation;
		this.Designation = designation;
	}
	
	/**
	 * @return the contId
	 */
	public int getContId() {
		return contId;
	}
	/**
	 * @param contId the contId to set
	 */
	public void setContId(int contId) {
		this.contId = contId;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the midName
	 */
	public String getMidName() {
		return midName;
	}
	/**
	 * @param midName the midName to set
	 */
	public void setMidName(String midName) {
		this.midName = midName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the gender
	 */
	public Gender getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	/**
	 * @return the mobileNumber1
	 */
	public String getMobileNumber1() {
		return mobileNumber1;
	}
	/**
	 * @param mobileNumber1 the mobileNumber1 to set
	 */
	public void setMobileNumber1(String mobileNumber1) {
		this.mobileNumber1 = mobileNumber1;
	}
	/**
	 * @return the mobileNumber2
	 */
	public String getMobileNumber2() {
		return mobileNumber2;
	}
	/**
	 * @param mobileNumber2 the mobileNumber2 to set
	 */
	public void setMobileNumber2(String mobileNumber2) {
		this.mobileNumber2 = mobileNumber2;
	}
	/**
	 * @return the officialEmail
	 */
	public String getOfficialEmail() {
		return officialEmail;
	}
	/**
	 * @param officialEmail the officialEmail to set
	 */
	public void setOfficialEmail(String officialEmail) {
		this.officialEmail = officialEmail;
	}
	/**
	 * @return the homeEmail
	 */
	public String getHomeEmail() {
		return homeEmail;
	}
	/**
	 * @param homeEmail the homeEmail to set
	 */
	public void setHomeEmail(String homeEmail) {
		this.homeEmail = homeEmail;
	}
	/**
	 * @return the category
	 */
	public Category getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(Category category) {
		this.category = category;
	}
	/**
	 * @return the organisation
	 */
	public String getOrganisation() {
		return Organisation;
	}
	/**
	 * @param organisation the organisation to set
	 */
	public void setOrganisation(String organisation) {
		Organisation = organisation;
	}
	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return Designation;
	}
	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		Designation = designation;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Contact [contId=" + contId + ", firstName=" + firstName
				+ ", midName=" + midName + ", lastName=" + lastName
				+ ", gender=" + gender + ", mobileNumber1=" + mobileNumber1
				+ ", mobileNumber2=" + mobileNumber2 + ", officialEmail="
				+ officialEmail + ", homeEmail=" + homeEmail + ", category="
				+ category + ", Organisation=" + Organisation
				+ ", Designation=" + Designation + "]";
	}

}
