package com.cg.ca.dto;

/**
 * @author arhansda
 *
 */
public enum Gender {
	MALE,FEMALE;
}
