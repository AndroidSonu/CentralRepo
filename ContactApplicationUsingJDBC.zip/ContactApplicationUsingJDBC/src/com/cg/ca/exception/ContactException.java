package com.cg.ca.exception;

/**
 * @author arhansda
 *
 */
public class ContactException extends Exception {
	public ContactException(String message) {
		super(message);
	}

}
