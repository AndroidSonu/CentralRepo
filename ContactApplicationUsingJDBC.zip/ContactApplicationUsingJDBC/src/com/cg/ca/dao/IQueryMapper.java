package com.cg.ca.dao;

/**
 * @author arhansda
 *
 */
public interface IQueryMapper {

	public static final String INSERT_CONT_QRY =
			"INSERT INTO contacts(contId,firstName,midName,lastName,gender,mobileNumber1,mobileNumber2,"
			+ "officialEmail,homeEmail,category,Organisation,Designation)"
			+ " VALUES(contIdSeq.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_CONT_QRY = 
			"UPDATE contacts SET firstName=?,midName=?,lastName=?,gender=?,mobileNumber1=?,mobileNumber2=?"
			+ ",officialEmail=?,homeEmail=?,category=?,Organisation=?,Designation=?";
	
	public static final String DELETE_CONT_QRY = 
			"DELETE FROM contacts WHERE contId=? ";
	
	public static final String SELECT_CONT_BY_ID_QRY = 
			"SELECT contId,firstName,midName,lastName,gender,mobileNumber1,mobileNumber2,officialEmail,"
			+ "homeEmail,category,Organisation,Designation FROM contacts WHERE contId=?";
	
	public static final String SELECT_ALL_CONT_QRY = 
			"SELECT contId,firstName,midName,lastName,gender,mobileNumber1,mobileNumber2,officialEmail,"
			+ "homeEmail,category,Organisation,Designation FROM contacts";
	
	
	
}
