package com.capgemini.hbms.controller;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.service.IHotelService;

@Controller
public class HotelController {

	@Autowired
	IHotelService hotelService;
	
	public IHotelService getHotelService() {
		return hotelService;
	}

	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}

	@RequestMapping("/index")
	public String showHome(){
		return ("homepage");
	}
	
	@RequestMapping(value="/custRegister",method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("users")Users user){
		ModelAndView mv = new ModelAndView();
		System.out.println(user.toString());
		int a= hotelService.addUser(user);
		if(a>0){
		String	msg = "Registered with User ID:"+a;
		mv.setViewName("error");
		mv.addObject("msg", msg);
		}else{
			mv.setViewName("error");
			mv.addObject("msg", "Registration Failed!!!");
		}
		return mv;
	}
	
	@RequestMapping("/adminPage")
	public String showAdmin(){
		return ("adminLogin");
	}
	
	@RequestMapping(value="/verifyAdmin",method=RequestMethod.POST)
	public ModelAndView verifyAdminLogin(@RequestParam("userId") int id,@RequestParam("password")  String pwd,HttpServletRequest request){
		ModelAndView mv = null;
		boolean status= hotelService.verifyLogin(id, pwd);
		Users user = hotelService.getUser(id);
		HttpSession session = request.getSession(false);
		if(status){
			session.setAttribute("user", user);
			mv = new ModelAndView("adminFunctions");
		}else{
			mv = new ModelAndView("error","msg","Unauthorised Access!!!");
		}
		return mv;
	}
	
	@RequestMapping("/custPage")
	public String showCust(){
		return ("custLogin");
	}
	
	@RequestMapping(value="/verifyCust",method=RequestMethod.POST)
	public ModelAndView verifyCustLogin(@RequestParam("userId") int id,@RequestParam("password") String pwd,HttpServletRequest request){
		ModelAndView mv = null;
		boolean status= hotelService.verifyCustLogin(id, pwd);
		Users user = hotelService.getUser(id);
		HttpSession session = request.getSession(false);
		if(status){
			session.setAttribute("user", user);
			mv = new ModelAndView("custFunctions");
		}else{
			mv = new ModelAndView("error","msg","Unauthorised Access!!!");
		}
		return mv;
	}
	
	
	
	@RequestMapping("/search")
	ModelAndView getCity(){
		ModelAndView mv=null;
		List<Hotel> hotelList=hotelService.getHotelList();
		Set<String> distinctCity=new TreeSet<String>();
		for(Hotel city:hotelList){
			distinctCity.add(city.getCity());
		}
		mv=new ModelAndView("search","distinctCity",distinctCity);
		mv.addObject("isFirst", true);
		
		return mv;
		
	}
	
	@RequestMapping("/listByCity")
	public ModelAndView listByCity(@ModelAttribute("hotel") Hotel hotel){
		ModelAndView mv = null;
		List<Hotel> hotelListByCity = hotelService.getHotelListByCity(hotel.getCity());
		if(!hotelListByCity.isEmpty()){
			mv=new ModelAndView("search","hotelList",hotelListByCity);
		}else{
			mv = new ModelAndView("error","msg","Hotels Not Available");
		}
		return mv;
	}
	
	@RequestMapping("/roomDetails")
	public ModelAndView roomList(@RequestParam("hotelId") int id){
		ModelAndView mv = null;
		List<RoomDetails> roomList = hotelService.getRoomListByHotelIdAndType(id);
		if(!roomList.isEmpty()){
			mv=new ModelAndView("search","roomList",roomList);
			mv.addObject("isFirst", false);
		}else{
			mv = new ModelAndView("error","msg","Hotels Not Available");
		}
		return mv;
	}
	
	@RequestMapping("/book")
	public ModelAndView book(@RequestParam("roomId") int id,HttpServletRequest request){
		ModelAndView mv = null;
		HttpSession session = request.getSession(false);
		Users user = (Users) session.getAttribute("user");
			mv=new ModelAndView("bookPage","userid",user.getUserId());
			mv.addObject("id", id);
		return mv;
	}
// to be changed
//	@RequestMapping("/confirmBook")
//	public ModelAndView confirmBook(@ModelAttribute("bookingDetail") BookingDetails bookingDetail,HttpServletRequest request){
//		ModelAndView mv = new ModelAndView();
//		BookingDetails bd = hotelService.calculateBookingAmount(bookingDetail);
//		int a = bd.getBookingId();
//		System.out.println(a);
//		if(a>0){
//			String	msg = "Booked with Booking ID:"+a;
//			mv.setViewName("error");
//			mv.addObject("msg", msg);
//			}else{
//				mv.setViewName("error");
//				mv.addObject("msg", "Booking Failed!!!");
//			}
//			return mv;
//	}
//	
	@RequestMapping("/logout")
	public ModelAndView LogOut(HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession(false);
		if(session != null){
			session.invalidate();
			mv.addObject("msg", "You have successfully logged out.");
		}
		mv.setViewName("logout");
		return mv;
	}
	
	//---------------------------------Manage Hotel------------------------- 
	
	@RequestMapping("/home")
	public String showadminHome(){
		return("adminFunctions");
	}
	
	@RequestMapping("/hotel")
	public String showHotels(){
		return("hotels");
	}
	
	@RequestMapping("/addHotel")
	public String showAddHotelPage(){
		return("addHotelPage");
	}
	
	@RequestMapping("/addHotels")
	public ModelAndView addHotels(@ModelAttribute("hotel")Hotel hotel){
		ModelAndView mv = new ModelAndView();
		int id = hotelService.addHotel(hotel);
		if(id>0){
			mv.setViewName("adminSuccess");
			mv.addObject("msg", "Hotel is Added With Hotel ID :"+id);
		}else{
			mv.setViewName("adminError");
			mv.addObject("msg", "Hotel is Not Added");
		}
		return mv;
	}
	
	@RequestMapping("/deleteHotel")
	public ModelAndView showDeleteHotelPage(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("deleteHotel");
		mv.addObject("isFirst", true);
		return mv;
	}
	
	@RequestMapping("/deleteHotels")
	public ModelAndView deleteHotels(@RequestParam("hotelId") int hotelId){
		ModelAndView mv = new ModelAndView();
		boolean status = hotelService.deleteHotel(hotelId);
		List<Hotel> list = hotelService.getHotelList();
		if(status){
			mv.setViewName("deleteHotel");
			mv.addObject("list", list);
		}else{
			mv.setViewName("adminError");
			mv.addObject("msg", "No Hotel is Found To Delete");
		}
		return mv;
	}
	
	@RequestMapping("/modifyHotel")
	public ModelAndView showModifyHotelPage(){
		ModelAndView mv = new ModelAndView();
		mv.setViewName("modifyHotel");
		mv.addObject("isFirst", true);
		return mv;
	}
	
	@RequestMapping("/modifyHotels")
	public ModelAndView modifyHotels(@RequestParam("hotelId") int hotelId,@RequestParam("description") String description,@RequestParam("avgRatePerNight") double rate){
		ModelAndView mv = new ModelAndView();
		Hotel hotel = hotelService.modifyHotel(description, rate, hotelId);
		if(hotel != null){
			mv.setViewName("modifyHotel");
			mv.addObject("hotel", hotel);
		}else{
			mv.setViewName("adminError");
			mv.addObject("msg", "No Hotel is Found To Update");
		}
		return mv;
	}
	
	//---------------------------------Manage Rooms------------------------- 
	
		@RequestMapping("/room")
		public String showRoomss(){
			return("rooms");
		}
		
		@RequestMapping("/addRoom")
		public String showAddRoomPage(){
			return("addRoomPage");
		}
		
		@RequestMapping("/deleteRoom")
		public String showDeleteRoomPage(){
			return("deleteRoom");
		}
		
		@RequestMapping("/modifyRoom")
		public String showModifyRoomPage(){
			return("modifyRoom");
		}
		
		
	//---------------------------------Generate Reports------------------------- 
		
		@RequestMapping("/report")
		public String showReports(){
			return("reports");
		}
		
		@RequestMapping("/hotelList")
		public String hotelList(){
			return("hotelList");
		}
		
		@RequestMapping("/bookingListByHotelId")
		public String bookingListByHotelId(){
			return("bookingList");
		}
		
		@RequestMapping("/guestList")
		public String guestList(){
			return("guestList");
		}	
	
		@RequestMapping("/bookingListByDate")
		public String bookingListByDate(){
			return("bookingList");
		}
}