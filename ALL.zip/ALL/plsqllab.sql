
--Q 1.1
DECLARE
V_Sample1 NUMBER(2);
V_Sample2 CONSTANT NUMBER(2) ;
V_Sample3 NUMBER(2) NOT NULL ;
V_Sample4 NUMBER(2) := 50;
V_Sample5 NUMBER(2) DEFAULT 25;

--Q1.2
DECLARE --outer block
var_num1 NUMBER := 5;
BEGIN
DECLARE --inner block
var_num1 NUMBER := 10;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
--Can outer block variable (var_num1) be printed here.IfYes,Print the same.
END;
--Can inner block variable(var_num1) be printed here.IfYes,Print the same.
END;


--Q 1.3
DECLARE
	e_emp     emp%ROWTYPE;
BEGIN
	SELECT *
	INTO e_emp
	FROM emp
	WHERE Empno = 7369;
 
	DBMS_OUTPUT.PUT_LINE(e_emp.Empno||' '||e_emp.Ename||' '||e_emp.job||' '||e_emp.mgr||' '||e_emp.Hiredate||' '||e_emp.Sal||' '||e_emp.Comm||' '||e_emp.Deptno);
 
END;
/
 
--Q 1.4
DECLARE 
     v_emp emp%ROWTYPE;
	 v_dept department_master.DEPT_NAME%TYPE ;
	 v_name VARCHAR2(10) ;
BEGIN
    v_name := &employee_name;
    SELECT *
    INTO   v_emp
    FROM emp
    WHERE emp.ename = v_name;
 
	SELECT d.DEPT_NAME
	INTO v_dept
	FROM department_master d INNER JOIN emp e ON d.dept_code=e.deptno
	WHERE e.ename= v_name;
 
	DBMS_OUTPUT.PUT_LINE(v_emp.EMPNO||','||v_emp.ENAME||','||v_emp.JOB||','||v_emp.MGR||','||v_emp.HIREDATE||','||v_emp.SAL||','||v_emp.COMM||','||v_emp.DEPTNO||','||v_dept);	
EXCEPTION
    WHEN NO_DATA_FOUND THEN
         DBMS_OUTPUT.PUT_LINE('DATA NOT PRESENT');	
END;
/
 
/*--------------OUTPUT------------------
Enter value for employee_name: 'BLAKE'
old   6:     v_name := &employee_name;
new   6:     v_name := 'BLAKE';
7698,BLAKE,MANAGER,7839,01-MAY-81,2850,,30,Electronics
--------------------------------------*/
 
--Q 1.5
DECLARE
    e_emp emp%ROWTYPE;
	inc NUMBER;
	new_inc NUMBER;
	CURSOR c_emp IS SELECT * FROM emp;
BEGIN
    OPEN c_emp;
 
	LOOP
	    FETCH c_emp INTO e_emp;
		EXIT WHEN c_emp%NOTFOUND;
 
		inc := e_emp.sal * 0.3;
		IF inc >5000
		THEN 
		    new_inc := 5000;
		ELSE
            new_inc := inc;		
		END IF;
 
        UPDATE emp
        SET sal = sal + new_inc
        WHERE empno = e_emp.empno;
 
        END LOOP;
        CLOSE c_emp;		
EXCEPTION
    WHEN NO_DATA_FOUND THEN
         DBMS_OUTPUT.PUT_LINE('DATA NOT PRESENT');	
 
END;
 
--Q 2.2
DECLARE
	v_sal   NUMBER;
	v_bonus	NUMBER;
	CURSOR sal_cursors IS 
					SELECT Staff_sal
					FROM Staff_Master
					WHERE mgr_code=100006;
BEGIN
	OPEN sal_cursors;
 
	LOOP
		FETCH sal_cursors INTO v_sal;
		EXIT WHEN sal_cursors%NOTFOUND;
		v_bonus := 2 * v_sal;
		DBMS_OUTPUT.PUT_LINE('Staff Salary is '||v_sal);
		DBMS_OUTPUT.PUT_LINE('Staff Bonus is '||v_bonus);
	END LOOP;
 
	CLOSE sal_cursors;
END;
/
 
--Q 2.3
DECLARE
	e_comm    emp.comm%TYPE;
	errmsg    EXCEPTION;
BEGIN
	SELECT Comm
	INTO e_comm
	FROM emp
	WHERE Empno = 7369;
 
	IF e_comm IS NULL
	THEN
		RAISE errmsg;
	END IF;
 
	DBMS_OUTPUT.PUT_LINE('Commission is '||e_comm);
EXCEPTION
	WHEN errmsg THEN
		DBMS_OUTPUT.PUT_LINE('No Commission exists');
END;
/
 
--Q 3.1
CREATE OR REPLACE FUNCTION AGE(dob staff_master.staff_dob%TYPE)
RETURN NUMBER
IS years NUMBER;
BEGIN
	years := ROUND((SYSDATE - dob)/365);
	RETURN years;
END;
/
 
--Q 3.2
CREATE OR REPLACE PROCEDURE FindManager(
	p_staffcode     IN   Staff_Master.Staff_Code%TYPE,
	p_staffcode1    OUT  Staff_Master.Staff_Code%TYPE,
	p_staffname     OUT  Staff_Master.Staff_Name%TYPE,
	p_deptcode      OUT  Staff_Master.Dept_Code%TYPE,
	p_mgrname       OUT  Staff_Master.Staff_Name%TYPE
)
IS  mgr   NUMBER;
	staff NUMBER;
BEGIN
	SELECT Staff_Code,Staff_Name,Dept_Code,mgr_code
	INTO p_staffcode1,p_staffname,p_deptcode,mgr
	FROM Staff_Master
	WHERE Staff_Code=p_staffcode;
 
	SELECT Staff_Code
	INTO staff
	FROM Staff_Master
	WHERE Staff_Code=mgr;
 
	SELECT Staff_Name
	INTO p_mgrname
	FROM Staff_Master
	WHERE Staff_Code=staff;
END;
/
 
--Q 3.3
CREATE OR REPLACE FUNCTION Cost(F_staffcode Staff_Master.Staff_Code%TYPE)
RETURN NUMBER
IS F_sal    NUMBER;
   F_da     NUMBER;
   F_hra    NUMBER;
   F_ta     NUMBER;
   F_sp     NUMBER;
   F_total  NUMBER;
   F_years  NUMBER;
   F_doj    DATE;
BEGIN
    SELECT Staff_sal,Hiredate
    INTO F_sal,F_doj
    FROM staff_master
    WHERE Staff_Code=F_staffcode;
 
    F_years := ROUND((SYSDATE-F_doj)/365);
 
    IF F_years < 1 THEN
		F_sp := 0;
    ELSIF F_years >=1 AND F_years < 2 THEN
		F_sp := 0.1 * F_sal;
	ELSIF F_years >=2 AND F_years < 4 THEN
		F_sp := 0.2 * F_sal;
	ELSE
		F_sp := 0.3 * F_sal;
	END IF;
 
	F_hra := 0.2 * F_sal;
 
	F_da := 0.15 * F_sal;
 
	F_ta := 0.08 * F_sal;
 
	F_total := F_sal + F_da + F_hra + F_ta + F_sp;
 
	RETURN F_total;
END;
/
 
--Q 3.4
CREATE OR REPLACE PROCEDURE updatesal(
	code   IN   Staff_Master.Staff_Code%TYPE
)
IS  service    NUMBER;
	hire       Staff_Master.HireDate%TYPE;
BEGIN
	SELECT HireDate
	INTO hire
	FROM Staff_Master
	WHERE Staff_Code=code;
 
	service := ROUND((SYSDATE-hire)/365);
 
	IF service > 2 AND service < 5 THEN
		UPDATE Staff_Master SET Staff_sal=Staff_sal + (0.2 * Staff_sal) WHERE Staff_Code=code;
	ELSIF service > 5 THEN
		UPDATE Staff_Master SET Staff_sal=Staff_sal + (0.25 * Staff_sal) WHERE Staff_Code=code;
	END IF;
END;
/
 
--Q 3.5
CREATE OR REPLACE PROCEDURE insertbook(
	bcode      IN    book_master.book_code%TYPE,
	scode      IN    staff_master.staff_code%TYPE
)
IS  issue     DATE;
	expreturn DATE;
BEGIN
	issue := SYSDATE;
	expreturn := SYSDATE + 10;
	IF(NEXT_DAY(SYSDATE,'Saturday')=expreturn) THEN
		expreturn := expreturn + 2;
	ELSIF(NEXT_DAY(SYSDATE,'Sunday')=expreturn) THEN
		expreturn := expreturn + 1;
	END IF;
 
	INSERT INTO book_transactions
	VALUES(bcode,NULL,scode,issue,expreturn,NULL);
END;
/