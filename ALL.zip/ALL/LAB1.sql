
------------------------------------1. Data Query Language-------------------------------------

Q1.
SQL> SELECT Staff_name as "Staff Name",Design_code as "Designation Code" from Staff_master where Hiredate < '01-jan-2003' and staff_sal between 12000 and 25000;

----------output---------
/*
STAFF_NAME                                         DESIGN_CODE
-------------------------------------------------- -----------
Shyam                                                      102
Mohan                                                      102
Anil                                                       102
*/
Q2.
SQL> SELECT Staff_code,Staff_name,Dept_code from Staff_master where (SYSDATE-Hiredate)/365 >=10;

----output-----
no rows selected

Q3.
SQL>SELECT * from Staff_master where Mgr_code is null;

------output-----
no rows selected

Q4.
SQL> SELECT * from Book_master where Book_pub_year between 2001 and 2004;

----------output-----------
/*
 BOOK_CODE BOOK_NAME                                          BOOK_PUB_YEAR
---------- -------------------------------------------------- -------------
BOOK_PUB_AUTHOR
--------------------------------------------------
  10000003 JAVA Complete Reference                                     2004
H.Schild

  10000007 Intoduction To Algorithams                                  2001
Cormen

  10000009 Introduction to O/S                                         2001
Millan

SQL> select * from Book_master where Book_name like '%&%';

no rows selected
*/
Q5.
SQL> SELECT Staff_name from Staff_master where Staff_name like '%_%';

-----------output---------------
/*
STAFF_NAME
--------------------------------------------------
Arvind
Shyam
Mohan
Anil
John
Allen
Smith
Raviraj
Rahul
Ram

10 rows selected.
*/
------------------------------------2.1 Single Row and Group Functions-------------------------------------- 
2.1
Q1.
SELECT STAFF_NAME,LPAD(STAFF_SAL,'15','$')
FROM STAFF_MASTER;
-----------output-------------
/*
SQL> SELECT STAFF_NAME,LPAD(STAFF_SAL,'15','$')
  2  FROM STAFF_MASTER;

STAFF_NAME
--------------------------------------------------
LPAD(STAFF_SAL,'15','$')
------------------------------------------------------------
Arvind
$$$$$$$$$$17000

Shyam
$$$$$$$$$$20000

Mohan
$$$$$$$$$$24000


STAFF_NAME
--------------------------------------------------
LPAD(STAFF_SAL,'15','$')
------------------------------------------------------------
Anil
$$$$$$$$$$20000

John
$$$$$$$$$$32000

Allen
$$$$$$$$$$42000


STAFF_NAME
--------------------------------------------------
LPAD(STAFF_SAL,'15','$')
------------------------------------------------------------
Smith
$$$$$$$$$$62000

Raviraj
$$$$$$$$$$18000

Rahul
$$$$$$$$$$22000


STAFF_NAME
--------------------------------------------------
LPAD(STAFF_SAL,'15','$')
------------------------------------------------------------
Ram
$$$$$$$$$$32000


10 rows selected.
*/

Q2.
SELECT STUDENT_NAME"name",to_char(student_dob,'Month,dd yyyy') "date of birth" from student_master where to_char(to_date(student_dob,'dd/mm/yyyy'), 'Dy')='Sun'
or to_char(to_date(student_dob,'dd/mm/yyyy'), 'Dy')='Sat';
-------------output--------------
/*
SQL> SELECT STUDENT_NAME"name",to_char(student_dob,'Month,dd yyyy') "date of birth" from student_master where to_char(to_date(student_dob,'dd/mm/yyyy'), 'Dy')='Sun'
  2  or to_char(to_date(student_dob,'dd/mm/yyyy'), 'Dy')='Sat';

name
--------------------------------------------------
date of birth
--------------------------------------------
Ajay
January  ,13 1982

Dev
March    ,11 1981

Rajesh
January  ,22 1980


name
--------------------------------------------------
date of birth
--------------------------------------------
Anil
January  ,23 1980

Kapil
March    ,18 1981

Ashok
November ,26 1980


name
--------------------------------------------------
date of birth
--------------------------------------------
Amrit
November ,11 1980

Sumit
January  ,01 1980


8 rows selected.
*/
Q3.
SELECT STAFF_NAME,ROUND((SYSDATE-HIREDATE)/30) AS "Months Worked"
from staff_master
ORDER BY((SYSDATE-HIREDATE)/30);
-------------output-------------
/*

SQL> SELECT STAFF_NAME,ROUND((SYSDATE-HIREDATE)/30) AS "Months Worked"
  2  from staff_master
  3  ORDER BY((SYSDATE-HIREDATE)/30);

STAFF_NAME                                         Months Worked
-------------------------------------------------- -------------
Rahul                                                        167
Arvind                                                       178
Raviraj                                                      178
Smith                                                        188
Shyam                                                        189
Mohan                                                        190
Ram                                                          190
Allen                                                        199
Anil                                                         201
John                                                         202

10 rows selected.
*/

Q4.
SELECT * FROM STAFF_MASTER WHERE (EXTRACT (DAY FROM HIREDATE))<=15 AND (EXTRACT(MONTH FROM HIREDATE))=12; 
-----------output---------
/*
SQL> SELECT * FROM STAFF_MASTER WHERE (EXTRACT (DAY FROM HIREDATE))<=15 AND (EXTRACT(MONTH FROM HIREDATE))=12;

STAFF_CODE STAFF_NAME                                         DESIGN_CODE
---------- -------------------------------------------------- -----------
 DEPT_CODE STAFF_DOB HIREDATE    MGR_CODE  STAFF_SAL
---------- --------- --------- ---------- ----------
STAFF_ADDRESS
--------------------------------------------------------------------------------
    100009 Rahul                                                      102
        20 16-JAN-78 11-DEC-03     100006      22000
Hyderabad

*/ 
Q5.
 
SELECT staff_name,staff_sal,case
    when staff_master.staff_sal >= 50000
       THEN 'A     '
    WHEN staff_master.staff_sal between 25000 and 50000
       then 'B     '
    WHEN staff_master.staff_sal BETWEEN 10000 AND 25000
       THEN 'C     '
    ELSE 'D     '
    END AS GRADE
FROM STAFF_MASTER;

-----------------output-------------
/*

SQL> SELECT staff_name,staff_sal,case
  2      when staff_master.staff_sal >= 50000
  3         THEN 'A     '
  4      WHEN staff_master.staff_sal between 25000 and 50000
  5         then 'B     '
  6      WHEN staff_master.staff_sal BETWEEN 10000 AND 25000
  7         THEN 'C     '
  8      ELSE 'D     '
  9      END AS GRADE
 10  FROM STAFF_MASTER;

STAFF_NAME                                          STAFF_SAL GRADE
-------------------------------------------------- ---------- ------
Arvind                                                  17000 C
Shyam                                                   20000 C
Mohan                                                   24000 C
Anil                                                    20000 C
John                                                    32000 B
Allen                                                   42000 B
Smith                                                   62000 A
Raviraj                                                 18000 C
Rahul                                                   22000 C
Ram                                                     32000 B

10 rows selected.
*/
 
Q6.
SELECT HIREDATE,DAY
FROM(SELECT STAFF_NAME,HIREDATE,TO_CHAR(HIREDATE,'dy') "DAY", TO_CHAR(HIREDATE-1,'D') AS days
from staff_master)
order by days;
--------------output------------
/*
SQL> SELECT HIREDATE,DAY
  2  FROM(SELECT STAFF_NAME,HIREDATE,TO_CHAR(HIREDATE,'dy') "DAY", TO_CHAR(HIREDATE-1,'D') AS days
  3  from staff_master)
  4  order by days;

HIREDATE  DAY
--------- ------------
23-APR-01 mon
12-MAR-02 tue
15-JAN-03 wed
11-DEC-03 thu
17-JAN-02 thu
11-JAN-03 sat
19-JAN-02 sat
11-MAR-01 sun
17-FEB-02 sun
21-JAN-01 sun

10 rows selected.
*/
 
Q7.
SELECT INSTR('Mississippi','i',1,3) AS "Third occurance"
from dual;
---------------output--------------
/*

SQL> SELECT INSTR('Mississippi','i',1,3) AS "Third occurance"
  2  from dual;

Third occurance
---------------
              8

*/
 
Q8.
SELECT TO_CHAR(NEXT_DAY(LAST_DAY(SYSDATE) -  INTERVAL '7' DAY,'FRIDAY'), 'Ddspth "of" Month YYYY')
FROM dual;
-----------output-----------
/*

SQL> SELECT TO_CHAR(NEXT_DAY(LAST_DAY(SYSDATE) -  INTERVAL '7' DAY,'FRIDAY'), 'Ddspth "of" Month YYYY')
  2  FROM dual;

TO_CHAR(NEXT_DAY(LAST_DAY(SYSDATE)-INTERVAL'7'DAY,'FRIDAY')
-----------------------------------------------------------
Twenty-Ninth of September 2017
*/
Q9.
SELECT Student_code, Student_name, DECODE(Dept_code, 20, 'Electricals', 30, 'Electronics', 'Others')
FROM student_master;
----------------output------------
/*

SQL> SELECT Student_code, Student_name, DECODE(Dept_code, 20, 'Electricals', 30, 'Electronics', 'Others')
  2  FROM student_master;

STUDENT_CODE STUDENT_NAME                                       DECODE(DEPT
------------ -------------------------------------------------- -----------
        1001 Amit                                               Others
        1002 Ravi                                               Others
        1003 Ajay                                               Electricals
        1004 Raj                                                Electronics
        1005 Arvind                                             Others
        1006 Rahul                                              Others
        1007 Mehul                                              Electricals
        1008 Dev                                                Others
        1009 Vijay                                              Electronics
        1010 Rajat                                              Others
        1011 Sunder                                             Others

STUDENT_CODE STUDENT_NAME                                       DECODE(DEPT
------------ -------------------------------------------------- -----------
        1012 Rajesh                                             Electronics
        1013 Anil                                               Electricals
        1014 Sunil                                              Others
        1015 Kapil                                              Others
        1016 Ashok                                              Others
        1017 Ramesh                                             Electronics
        1018 Amit Raj                                           Others
        1019 Ravi Raj                                           Others
        1020 Amrit                                              Others
        1021 Sumit                                              Electricals

21 rows selected.

*/
 
 
----------------------------------2.2 Group Functions---------------------------------------

Q1.
SELECT MAX(STAFF_SAL) AS "Maximum",MIN(STAFF_SAL) AS "Minimum",SUM(STAFF_SAL) as "Total",ROUND(AVG(STAFF_SAL)) as "Average" from staff_master; 
 -----------output----------
 /*
 
SQL> SELECT MAX(STAFF_SAL) AS "Maximum",MIN(STAFF_SAL) AS "Minimum",SUM(STAFF_SAL) as "Total",ROUND(AVG(STAFF_SAL)) as "Average" from staff_master;

   Maximum    Minimum      Total    Average
---------- ---------- ---------- ----------
     62000      17000     289000      28900
 */
Q2.
 
SELECT DEPT_CODE,COUNT(*) AS "Total Number of Managers" 
FROM STAFF_MASTER
WHERE STAFF_CODE IN(SELECT DISTINCT(MGR_CODE)FROM STAFF_MASTER)
GROUP BY DEPT_CODE;
---------------output--------------
/*

SQL> SELECT DEPT_CODE,COUNT(*) AS "Total Number of Managers"
  2  FROM STAFF_MASTER
  3  WHERE STAFF_CODE IN(SELECT DISTINCT(MGR_CODE)FROM STAFF_MASTER)
  4  GROUP BY DEPT_CODE;

 DEPT_CODE Total Number of Managers
---------- ------------------------
        30                        1
        20                        1
        10                        1

*/
Q3.
 
SELECT DEPT_CODE,SUM(STAFF_SAL)
FROM STAFF_MASTER
WHERE STAFF_CODE not IN(SELECT DISTINCT(MGR_CODE) FROM STAFF_MASTER)
GROUP BY DEPT_CODE HAVING SUM (STAFF_SAL)>20000;
------------output-------------
/*

SQL> SELECT DEPT_CODE,SUM(STAFF_SAL)
  2  FROM STAFF_MASTER
  3  WHERE STAFF_CODE not IN(SELECT DISTINCT(MGR_CODE) FROM STAFF_MASTER)
  4  GROUP BY DEPT_CODE HAVING SUM (STAFF_SAL)>20000;

 DEPT_CODE SUM(STAFF_SAL)
---------- --------------
        30          49000
        20          62000
        10          24000

*/

-----------------------------------------------3. Join and SubQueries----------------------------------------------------

Q1. 
SQL> SELECT Staff_master.Staff_name,Department_master.Dept_code,Department_master.Dept_name
  2  FROM Staff_master INNER JOIN Department_master ON Department_master.Dept_code=Staff_master
  3  WHERE Staff_sal>20000;
  
----------------output----------------------
/*
STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME
--------------------------------------------------
Mohan                                                      10
Computer Science

John                                                       10
Computer Science

Allen                                                      30
Electronics


STAFF_NAME                                          DEPT_CODE
-------------------------------------------------- ----------
DEPT_NAME
--------------------------------------------------
Smith                                                      20
Electricals

Rahul                                                      20
Electricals

Ram                                                        30
Electronics


6 rows selected.
*/
Q2.
SQL> SELECT s.staff_code,s.staff_name,d.dept_name,e.staff_code,e.staff_name AS "Manager"
  2  FROM staff_master s INNER JOIN staff_master e ON s.mgr_code=e.staff_code
  3  INNER JOIN department_master d on d.dept_code=s.dept_code;
  
 ----------output--------------
/*
STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100007 Smith
Electricals                                            100005
John

    100006 Allen
Electronics                                            100005
John

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100009 Rahul
Electricals                                            100006
Allen

    100008 Raviraj
Mechanics                                              100006

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Allen

    100004 Anil
Electricals                                            100006
Allen

    100003 Mohan

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------
Computer Science                                       100006
Allen

    100001 Arvind
Electronics                                            100006
Allen


STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------
    100010 Ram
Electronics                                            100007
Smith

    100005 John
Computer Science                                       100007
Smith

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME                                          STAFF_CODE
-------------------------------------------------- ----------
Manager
--------------------------------------------------

    100002 Shyam
Electricals                                            100007
Smith


10 rows selected.
*/
Q3.
SQL> SELECT s.student_code,s.student_name,b.book_code,b.book_name FROM Student_master s INNER JOIN Book_transactions bt
  2  ON s.student_code=bt.student_code
  3  INNER JOIN Book_master b ON b.Book_code=bt.Book_code
  4  WHERE book_expected_return_date=(SELECT SYSDATE FROM dual);
  
 -----------output---------------
/*
no rows selected.
*/
Q4.
SQL> SELECT s.staff_code,s.staff_name,d.dept_name,dm.design_name,b.book_code,b.book_name,bt.book_issue_date FROM
  2  Staff_master s INNER JOIN  designation_master dm ON s.design_code=dm.design_code
  3  INNER JOIN  department_master d ON s.dept_code=d.dept_code
  4  INNER JOIN book_transactions bt ON s.staff_code=bt.staff_code
  5  INNER JOIN book_master b ON bt.book_code=b.book_code
  6  WHERE (SYSDATE-bt.book_issue_date)<=30;

 ------------output----------
 /*
no rows selected.
*/

Q5.
SQL> SELECT s.staff_code,s.staff_name,dm.design_name,d.dept_name,b.book_code,b.book_name,b.book_pub_author,ABS(bt.book_actual_return_date-bt.book_expected_return_dat
e)*5 AS Fine FROM
  2      Staff_master s INNER JOIN  designation_master dm ON s.design_code=dm.design_code
  3      INNER JOIN  department_master d ON s.dept_code=d.dept_code
  4      INNER JOIN book_transactions bt ON s.staff_code=bt.staff_code
  5      INNER JOIN book_master b ON bt.book_code=b.book_code
  6    WHERE (bt.book_actual_return_date-bt.book_expected_return_date)>0;
  
-------------output--------------
/*
STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          FINE
-------------------------------------------------- ----------
    100010 Ram
Reader
Electronics                                          10000009

STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DESIGN_NAME
--------------------------------------------------
DEPT_NAME                                           BOOK_CODE
-------------------------------------------------- ----------
BOOK_NAME
--------------------------------------------------
BOOK_PUB_AUTHOR                                          FINE
-------------------------------------------------- ----------
Introduction to O/S
Millan                                                     10
*/
Q6.
SQL> SELECT staff_code,staff_name,staff_sal FROM staff_master WHERE staff_sal<(SELECT avg(staff_sal) FROM staff_master);

-----------------output----------------
/*
STAFF_CODE STAFF_NAME                                          STAFF_SAL
---------- -------------------------------------------------- ----------
    100001 Arvind                                                  17000
    100002 Shyam                                                   20000
    100003 Mohan                                                   24000
    100004 Anil                                                    20000
    100008 Raviraj                                                 18000
    100009 Rahul                                                   22000

6 rows selected.
*/

Q7.
SQL> SELECT book_pub_author,book_name FROM (SELECT COUNT(*),book_pub_author,book_name FROM book_master GROUP BY book_pub_author,book_name HAVING COUNT(*)>1);

----------------output-------------
/*
BOOK_PUB_AUTHOR
--------------------------------------------------
BOOK_NAME
--------------------------------------------------
H.Schild
JAVA Complete Reference

Tanenbaum
Computer Networks

H. Schild
J2EE Complete Reference


BOOK_PUB_AUTHOR
--------------------------------------------------
BOOK_NAME
--------------------------------------------------
Millan
Introduction to O/S

Cormen
Intoduction To Algorithams

B.C. Desai
Relational DBMS


BOOK_PUB_AUTHOR
--------------------------------------------------
BOOK_NAME
--------------------------------------------------
Yashavant Kanetkar
Let Us C++

P.J Allen
Mastersing VC++

Yashavant Kanetkar
Let Us C


9 rows selected.
*/
Q8.
SQL> SELECT s.staff_code,s.staff_name,b.dept_name FROM Staff_master s
  2  INNER JOIN (SELECT s.staff_code FROM staff_master s
  3  INNER JOIN book_transactions c ON s.staff_code=c.staff_code
  4  GROUP BY s.staff_code HAVING COUNT(*)>1) d ON s.staff_code=d.staff_code
  5  INNER JOIN department_master b ON s.dept_code=b.dept_code;
  
 ---------------output--------------
/*
STAFF_CODE STAFF_NAME
---------- --------------------------------------------------
DEPT_NAME
--------------------------------------------------
    100006 Allen
Electronics

    100007 Smith
Electricals
*/
Q9.

SQL> SELECT student_code,student_name,dept_name FROM student_master s
  2  INNER JOIN department_master d ON s.dept_code=d.dept_code
  3  WHERE d.dept_code=(SELECT s.dept_code
  4                             FROM  student_master s INNER JOIN department_master d ON s.dept_code=d.dept_code
  5                             GROUP BY s.dept_code
  6                             HAVING COUNT(*)=(SELECT max(count(*))
  7                                                             FROM student_master s INNER JOIN department_master d ON s.dept_code=d.dept_code
  8                                                             GROUP BY s.dept_code));

 ---------------output----------------- 
/*  
STUDENT_CODE STUDENT_NAME
------------ --------------------------------------------------
DEPT_NAME
--------------------------------------------------
        1001 Amit
Computer Science

        1002 Ravi
Computer Science

        1008 Dev
Computer Science


STUDENT_CODE STUDENT_NAME
------------ --------------------------------------------------
DEPT_NAME
--------------------------------------------------
        1014 Sunil
Computer Science

        1020 Amrit
Computer Science
*/

Q10.
SQL>  SELECT s.staff_code,s.staff_name,d.dept_name,b.design_name
  2  FROM Staff_master s
  3  INNER JOIN Designation_master b ON b.design_code=s.design_code
  4  INNER JOIN Department_master d ON d.dept_code=s.dept_code
  5  WHERE (SYSDATE-s.hiredate)<90;
  
---------------output--------------
no rows selected.
 
 
Q11.
SQL> SELECT s.staff_name "Manager Name",m.count "Total strength"
  2  FROM staff_master s INNER JOIN (SELECT mgr_code,count(*) AS count
  3  FROM staff_master
  4  GROUP BY mgr_code)m ON m.mgr_code=s.staff_code;
  
-------------output----------------
/*
Manager Name                                       Total strength
-------------------------------------------------- --------------
John                                                            2
Allen                                                           5
Smith                                                           3

*/
 Q12.
SQL>  SELECT t.book_code,b.book_name FROM book_master b
  2   JOIN book_transactions t ON t.book_code=b.book_code
  3   WHERE t.book_actual_return_date IS NULL AND NEXT_DAY(SYSDATE-7,'monday')=(t.book_expected_return_date);
  
------------output-----------
no rows selected.

Q13.
SQL> SELECT d.dept_code,d.dept_name,COUNT(s.staff_code) FROM department_master d
  2  INNER JOIN staff_master s ON d.dept_code=s.dept_code GROUP BY d.dept_code,dept_name;
  
-------------output-------------
/*
 DEPT_CODE DEPT_NAME
---------- --------------------------------------------------
COUNT(S.STAFF_CODE)
-------------------
        30 Electronics
                  3

        20 Electricals
                  4

        10 Computer Science
                  2


 DEPT_CODE DEPT_NAME
---------- --------------------------------------------------
COUNT(S.STAFF_CODE)
-------------------
        40 Mechanics
                  1

				  
				  


*/
-------------------------------------4. Database Objects----------------------------------------------------

1.
CREATE TABLE Customer (
	CustomerId 	NUMBER(5),
	Cust_Name 	VARCHAR2(20),
	Address1 	VARCHAR2(30),
	Address2 	VARCHAR2(30)
);
 /*----------OUTPUT-----------
 Table altered.
 -------------------------*/
2.
ALTER TABLE Customer
RENAME COLUMN Cust_Name TO CustomerName;
 
ALTER TABLE Customer
MODIFY (CustomerName VARCHAR2(30) NOT NULL);
/*-------------OUTPUT-----------
Table altered.
----------*/
 
3.
 a)
 
ALTER TABLE Customer
ADD (	Gender 	VARCHAR2(1),
		Age 	NUMBER(3),
		PhoneNo NUMBER(10)
	);
 /*-----------OUTPUT-----------
 Table altered.
 -----------*/
 b)
 
RENAME Customer TO Cust_Table;
/*----------OUTPUT-----------
Table renamed.
-------------------------*/
4.
 
INSERT INTO Cust_Table VALUES(1000, 'Allen', '#115 Chicago', '#115 Chicago','M',25,7878776);
INSERT INTO Cust_Table VALUES(1001, 'George', '#116 France', '#116 France','M', 25, 434524);
INSERT INTO Cust_Table VALUES(1002,'Becker', '#114 New York', '#114 New York', 'M', 45, 431525);
 
/*----------OUTPUT-----------
 
SQL> INSERT INTO Cust_Table VALUES(1000, 'Allen', '#115 Chicago', '#115 Chicago'
,'M',25,7878776);
 
1 row created.
 
SQL> INSERT INTO Cust_Table VALUES(1001, 'George', '#116 France', '#116 France',
'M', 25, 434524);
 
1 row created.
 
SQL> INSERT INTO Cust_Table VALUES(1002,'Becker', '#114 New York', '#114 New Yor
k', 'M', 45, 431525);
 
1 row created.
----------------------------*/
 
5.
ALTER TABLE Cust_Table
ADD CONSTRAINT Custld_Prim
PRIMARY KEY (CustomerId);
 
/*------OUTPUT----------------
Table altered.
-----------------------------*/
6.
INSERT INTO Cust_Table VALUES(1002,'John', '#114 Chicago', '#114 Chicago', 'M', 45, 439525);
/*------OUTPUT----------------
ERROR at line 1:
ORA-00001: unique constraint (SYSTEM.CUSTLD_PRIM) violated
-----------------------------*/
7.
ALTER TABLE CUST_TABLE
DISABLE CONSTRAINT Custld_Prim;
 
INSERT INTO Cust_Table VALUES(1002,'Becker', '#114 New York', '#114 New york' , 'M', 45, 431525);
INSERT INTO Cust_Table VALUES(1003, 'Nanapatekar', '#115 India', '#115 India' ,'M', 45, 431525);
/*---------------OUTPUT----------------
 
SQL> ALTER TABLE CUST_TABLE
  2  DISABLE CONSTRAINT Custld_Prim;
 
Table altered.
 
SQL>
SQL> INSERT INTO Cust_Table VALUES(1002,'Becker', '#114 New York', '#114 New yor
k' , 'M', 45, 431525);
 
1 row created.
 
SQL> INSERT INTO Cust_Table VALUES(1003, 'Nanapatekar', '#115 India', '#115 Indi
a' ,'M', 45, 431525);
 
1 row created.
------------------------------------*/
 
8.
ALTER TABLE CUST_TABLE
ENABLE CONSTRAINT Custld_Prim;
/*-------OUTPUT-----------
ALTER TABLE CUST_TABLE
*
ERROR at line 1:
ORA-02437: cannot validate (SYSTEM.CUSTLD_PRIM) - primary key violated
------------------------*/
 
9.
ALTER TABLE CUST_TABLE
DROP CONSTRAINT Custld_Prim;
 
INSERT INTO Cust_Table VALUES(1002, 'Becker', '#114 New York', '#114 New york ', 'M', 45, 431525, 15000.50);
INSERT INTO Cust_Table VALUES(1003, 'Nanapatekar', '#115 India', '#115 India' , 'M', 45, 431525, 20000.50);
 
/*---------OUTPUT----------- 
ORA-00913: too many values
--------------------------*/
 
10.
TRUNCATE TABLE CUST_TABLE;
/*---------OUTPUT----------- 
Table truncated.
--------------------------*/
 
11.
ALTER TABLE CUST_TABLE
ADD (	E_mail 	VARCHAR2(20)
	);
 
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
 
12.
ALTER TABLE CUST_TABLE
DROP COLUMN E_mail;
 
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
 
13.
CREATE TABLE Suppliers (
	SuppID 		NUMBER(5),
	SName 		VARCHAR2(20),
	Addr1 		VARCHAR2(30),
	Addr2 		VARCHAR2(30),
	Contactno 	NUMBER(10)
);
/*---------OUTPUT----------- 
Table created.
--------------------------*/
 
14.
DROP TABLE Suppliers;
/*---------OUTPUT----------- 
Table dropped.
--------------------------*/
CREATE TABLE CustomerMaster (
	CustomerId 		NUMBER(5),
	CustomerName 	VARCHAR2(30) NOT NULL,
	Address1 		VARCHAR2(30) NOT NULL,
	Address2 		VARCHAR2(30),
	Gender 			VARCHAR2(1),
	Age 			NUMBER(3),
	PhoneNo 		NUMBER(10),
	CONSTRAINT CustId_PK PRIMARY KEY(CustomerId)
);
/*---------OUTPUT----------- 
Table created.
--------------------------*/
 
15.
CREATE TABLE AccountsMaster (
	CustomerId 		NUMBER(5),
	AccountNumber 	NUMBER(10,2),
	AccountType		CHAR(3),
	LedgerBalance 	NUMBER(10)  NOT NULL,
	CONSTRAINT Acc_PK PRIMARY KEY(AccountNumber)
);
/*---------OUTPUT----------- 
Table created.
--------------------------*/
 
CREATE SEQUENCE SEQ_AccountNumber
START WITH 1
INCREMENT BY 1;
/*---------OUTPUT----------- 
Sequence created.
--------------------------*/
 
16.
ADD CONSTRAINT Cust_acc FOREIGN KEY (CustomerId) REFERENCES CustomerMaster(CustomerId);
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
 
17.
 
INSERT INTO CustomerMaster VALUES(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776);
INSERT INTO CustomerMaster VALUES(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524);
INSERT INTO CustomerMaster VALUES(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525);
 
/*---------OUTPUT----------- 
SQL> INSERT INTO CustomerMaster VALUES(1000, 'Allen', '#115 Chicago', '#115 Chic
ago', 'M', 25, 7878776);
 
1 row created.
 
SQL> INSERT INTO CustomerMaster VALUES(1001, 'George', '#116 France', '#116 Fran
ce', 'M', 25, 434524);
 
1 row created.
 
SQL> INSERT INTO CustomerMaster VALUES(1002, 'Becker', '#114 New York', '#114 Ne
w York', 'M', 45, 431525);
 
1 row created.
--------------------------*/
 
18.
 
ALTER TABLE AccountsMaster
ADD CONSTRAINT AccType Check (AccountType = 'NRI' OR AccountType = 'IND');
/*---------OUTPUT----------- 
 Table altered.
--------------------------*/
 
 
19.
 
ALTER TABLE AccountsMaster
ADD CONSTRAINT Balance_Check Check (LedgerBalance >= 5000);
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
--20.Modify the AccountsMaster table such that if Customer is deleted from Customer table then all his details should be deleted from AccountsMaster table.
 
ALTER TABLE AccountsMaster
DROP CONSTRAINT Cust_acc;
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
ALTER TABLE AccountsMaster
ADD CONSTRAINT Cust_acc FOREIGN KEY (CustomerId) REFERENCES CustomerMaster(CustomerId)
ON DELETE CASCADE;
/*---------OUTPUT----------- 
Table altered.
--------------------------*/
 
21.
CREATE TABLE AccountDetails AS
SELECT * FROM AccountsMaster;
/*---------OUTPUT----------- 
Table created.
--------------------------*/

------------------------------------------5.Data Manipulation Language------------------------------------------

Q1.
 
CREATE TABLE Employee AS SELECT * FROM emp WHERE 1=3;
 
DESC Employee;
----------output----------
/*
SQL> CREATE TABLE Employee AS SELECT * FROM emp WHERE 1=3;

Table created.

SQL>
SQL> DESC Employee;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 EMPNO                                     NOT NULL NUMBER(4)
 ENAME                                              VARCHAR2(10)
 JOB                                                VARCHAR2(9)
 MGR                                                NUMBER(4)
 HIREDATE                                           DATE
 SAL                                                NUMBER(7,2)
 COMM                                               NUMBER(7,2)
 DEPTNO                                             NUMBER(2)
 
 */
 
Q2.
 
SELECT * FROM Employee;
 
INSERT INTO Employee(EMPNO,ENAME,SAL,DEPTNO) 
SELECT EMPNO,ENAME,SAL,DEPTNO FROM emp;
 
SELECT * FROM Employee;

-----------output----------
/*
SQL> SELECT * FROM Employee;

no rows selected

SQL>
SQL> INSERT INTO Employee(EMPNO,ENAME,SAL,DEPTNO)
  2  SELECT EMPNO,ENAME,SAL,DEPTNO FROM emp;

14 rows created.


SQL> SELECT * FROM Employee;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH                                            800
        20

      7499 ALLEN                                           1600
        30

      7521 WARD                                            1250
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7566 JONES                                           2975
        20

      7654 MARTIN                                          1250
        30

      7698 BLAKE                                           2850
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7782 CLARK                                           2450
        10

      7788 SCOTT                                           3000
        20

      7839 KING                                            5000
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER                                          1500
        30

      7876 ADAMS                                           1100
        20

      7900 JAMES                                            950
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7902 FORD                                            3000
        20

      7934 MILLER                                          1300
        10


14 rows selected.
*/

Q3. 
 
UPDATE Employee
SET JOB = 	(SELECT JOB FROM Employee WHERE EMPNO = 7788),
	DEPTNO =(SELECT DEPTNO FROM Employee WHERE EMPNO = 7788)
WHERE EMPNO = 7698;
-----------output------------
/*
SQL> UPDATE Employee
  2  SET JOB =  (SELECT JOB FROM Employee WHERE EMPNO = 7788),
  3     DEPTNO =(SELECT DEPTNO FROM Employee WHERE EMPNO = 7788)
  4  WHERE EMPNO = 7698;

1 row updated.
*/

Q4.
 
DELETE FROM DEPARTMENT_MASTER
WHERE DEPT_NAME = 'SALES';
----------output------------
/*

SQL> DELETE FROM DEPARTMENT_MASTER
  2  WHERE DEPT_NAME = 'SALES';

0 rows deleted.
*/
 
Q5.
 
UPDATE Employee
SET DEPTNO =(SELECT DEPTNO FROM Employee WHERE EMPNO = 7698)
WHERE EMPNO = 7788;
 
 ------------ouput----------------
 /*
 
SQL> UPDATE Employee
  2  SET DEPTNO =(SELECT DEPTNO FROM Employee WHERE EMPNO = 7698)
  3  WHERE EMPNO = 7788;

1 row updated.
*/
Q6.
 
INSERT INTO Employee VALUES(1000,'Allen', 'Clerk',1001,'12-jan-01', 3000, 2,10);
INSERT INTO Employee VALUES(1001,'George', 'analyst', null, '08-Sep-92', 5000,0, 10);
INSERT INTO Employee VALUES(1002, 'Becker', 'Manager', 1000, '4-Nov-92', 2800,4, 20);
INSERT INTO Employee VALUES(1002, 'Becker', 'Manager', 1000, '4-Nov-92', 2800,4, 20);

----------------output----------------
/*
SQL> INSERT INTO Employee VALUES(1000,'Allen', 'Clerk',1001,'12-jan-01', 3000, 2,10);

1 row created.

SQL> INSERT INTO Employee VALUES(1001,'George', 'analyst', null, '08-Sep-92', 5000,0, 10);

1 row created.

SQL> INSERT INTO Employee VALUES(1002, 'Becker', 'Manager', 1000, '4-Nov-92', 2800,4, 20);

1 row created.

SQL> INSERT INTO Employee VALUES(1002, 'Becker', 'Manager', 1000, '4-Nov-92', 2800,4, 20);

1 row created.
*/