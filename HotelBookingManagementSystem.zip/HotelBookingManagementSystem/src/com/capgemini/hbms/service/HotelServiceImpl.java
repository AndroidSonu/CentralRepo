package com.capgemini.hbms.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	IHotelDao hotelDao;
	
	@Override
	public boolean verifyLogin(int id, String password) {

		return hotelDao.verifyLogin(id, password);
		
	}

	@Override
	public boolean verifyCustLogin(int id, String password) {
		
		return hotelDao.verifyCustLogin(id, password);
	}

	@Override
	public int addHotel(Hotel hotel) {
		return hotelDao.addHotel(hotel);
	}

	@Override
	public boolean deleteHotel(int hotelId) {
		return hotelDao.deleteHotel(hotelId);
	}

	@Override
	public Hotel modifyHotel(String hotelDesc, double avgRate, int hotelId) {
		return hotelDao.modifyHotel(hotelDesc, avgRate, hotelId);
	}

	@Override
	public int addRoom(RoomDetails room) {
		return hotelDao.addRoom(room);
	}

	@Override
	public boolean deleteRoom(int roomId) {
		return hotelDao.deleteRoom(roomId);
	}

	@Override
	public RoomDetails modifyRoom(int roomId, double rent) {
		return hotelDao.modifyRoom(roomId, rent);
	}

	@Override
	public List<Hotel> getHotelList() {
		return hotelDao.getHotelList();
	}

	@Override
	public List<BookingDetails> getBookingDetails(int hotelId) {
		return hotelDao.getBookingDetails(hotelId);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByDate(Date bookingDate) {
		return hotelDao.getBookingDetailsByDate(bookingDate);
	}

	@Override
	public List<Users> getGuestListByHotel_Id(int hotel_id) {
		return hotelDao.getGuestListByHotel_Id(hotel_id);
	}

	@Override
	public int addBookingDetails(BookingDetails bookingDetails) {
		return hotelDao.addBookingDetails(bookingDetails);
	}

//	@Override
//	public BookingDetails calculateBookingAmount(double rate,String date1,String date2,int noOfAdults,int noOfChildren,int roomId,int userId) {
//		return hotelDao.calculateBookingAmount(rate, date1,date2, noOfAdults,noOfChildren,roomId,userId);
//	}

	@Override
	public List<Hotel> getHotelListByCity(String city) {
		return hotelDao.getHotelListByCity(city);
	}

	@Override
	public List<RoomDetails> getRoomListByHotelIdAndType(int hotelId) {
		return hotelDao.getRoomListByHotelIdAndType(hotelId);
	}

	@Override
	public List<BookingDetails> getBookingDetailsByBookingId(int bookingId) {
		return hotelDao.getBookingDetailsByBookingId(bookingId);
	}

	@Override
	public int addUser(Users user) {
		return hotelDao.addUser(user);
	}

	@Override
	public RoomDetails updateRoomAvailability(int room_id) {
		return hotelDao.updateRoomAvailability(room_id);
	}

	@Override
	public Users getUser(int userId) {
		return hotelDao.getUser(userId);
	}

	@Override
	public List<RoomDetails> getRoomList() {
		// TODO Auto-generated method stub
		return hotelDao.getRoomList();
	}

	@Override
	public BookingDetails calculateBookingAmount(double rate, String date1,
			String date2, int noOfAdults, int noOfChildren, int roomId,
			int userId) {
		// TODO Auto-generated method stub
		return hotelDao.calculateBookingAmount(rate, date1, date2, noOfAdults, noOfChildren, roomId, userId);
	}

}

